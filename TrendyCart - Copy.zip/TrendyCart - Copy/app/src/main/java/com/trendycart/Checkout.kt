package com.trendycart

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.auth.FirebaseAuth
import com.trendycart.databinding.ActivityCheckoutBinding
import com.trendycart.databinding.ActivitySignUpBinding

class Checkout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)
        val binding = ActivityCheckoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var firebaseAuth = FirebaseAuth.getInstance()

        binding.textView36.setOnClickListener {
            val intent = Intent(this, Payment::class.java)
            startActivity(intent)
        }

    }
}