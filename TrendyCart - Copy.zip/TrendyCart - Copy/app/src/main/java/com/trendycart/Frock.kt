package com.trendycart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Frock : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frock)
    }
}