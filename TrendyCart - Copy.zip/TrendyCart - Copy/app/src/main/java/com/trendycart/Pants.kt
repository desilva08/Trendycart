package com.trendycart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Pants : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pants)
    }
}